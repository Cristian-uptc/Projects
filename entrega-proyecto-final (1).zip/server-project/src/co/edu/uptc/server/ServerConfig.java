package co.edu.uptc.server;

public final class ServerConfig {

    public static final int PORT = 5000;
    public static final String DATA_FILE = "data/system.dat";

    private ServerConfig() {
    }
}
